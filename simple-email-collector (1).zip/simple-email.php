<?php
/*
Plugin Name: Simple Email Collector
Description: A simple plugin to collect and store email addresses. [inline_form]
Version: 1.0
Author: Chandan
*/

// Create a new table for storing emails on plugin activation
function create_email_table() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'email_collector';

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        email varchar(100) NOT NULL,
        time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
register_activation_hook(__FILE__, 'create_email_table');

// Handle the form submission
function handle_form_submission() {
    if (isset($_POST['your-email'])) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'email_collector';

        $wpdb->insert(
            $table_name,
            array(
                'email' => $_POST['your-email'],
                'time' => current_time('mysql'),
            )
        );
    }
}
add_action('init', 'handle_form_submission');

// Add a page in the admin panel to view the emails
function add_email_page() {
    add_menu_page('Email Collector', 'Email Collector', 'manage_options', 'email-collector', 'email_collector_page');
}
add_action('admin_menu', 'add_email_page');

// The function to output the HTML for the admin page
function email_collector_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'email_collector';
    $results = $wpdb->get_results("SELECT * FROM $table_name");

    // Handle delete request
    if (isset($_POST['delete']) && isset($_POST['email_id'])) {
        $wpdb->delete($table_name, array('id' => $_POST['email_id']));
        echo '<div class="updated"><p>Email deleted</p></div>';
        $results = $wpdb->get_results("SELECT * FROM $table_name"); // Refresh the results
    }

    // Handle CSV download request
    if (isset($_POST['download_csv'])) {
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="emails.csv"');

        $fp = fopen('php://output', 'w');
        fputcsv($fp, array('Email', 'Time'));

        foreach ($results as $row) {
            fputcsv($fp, array($row->email, $row->time));
        }

        fclose($fp);
        exit;
    }

    echo '<h1>Email Addresses</h1>';
    echo '<form method="post">';
    echo '<input type="submit" name="download_csv" value="Download Emails (CSV)" class="button-primary">';
    echo '</form>';
    echo '<table>';
    echo '<tr><th>Email</th><th>Time</th><th>Action</th></tr>';

    foreach ($results as $row) {
        echo '<tr><td>' . $row->email . '</td><td>' . $row->time . '</td>';
        echo '<td><form method="post"><input type="hidden" name="email_id" value="' . $row->id . '"><input type="submit" name="delete" value="Delete" class="button"></form></td></tr>';
    }

    echo '</table>';
}

// Remove the table when the plugin is uninstalled
function remove_email_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'email_collector';

    $wpdb->query("DROP TABLE IF EXISTS $table_name");
}
register_uninstall_hook(__FILE__, 'remove_email_table');

// Cleanup code to run when the plugin is deactivated
function deactivate_plugin() {
    // Remove the admin page
    remove_menu_page('email-collector');
}
register_deactivation_hook(__FILE__, 'deactivate_plugin');

// Add the shortcode for the form
function inline_form_shortcode() {
    ob_start(); ?>
    <div class="inline-form">
        <form method="post" style="display: flex; align-items: center; font-family:Nunito;">
            <input type="email" name="your-email" placeholder="Your Email" required style="margin-right: 10px; font-family:Nunito;">
            <input type="submit" value="Subscribe">
        </form>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('inline_form', 'inline_form_shortcode');
?>
